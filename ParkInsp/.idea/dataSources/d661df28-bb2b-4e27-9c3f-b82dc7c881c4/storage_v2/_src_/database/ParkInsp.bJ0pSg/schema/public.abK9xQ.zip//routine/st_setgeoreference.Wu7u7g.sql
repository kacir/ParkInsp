create function st_setgeoreference(rast raster, upperleftx double precision, upperlefty double precision, scalex double precision, scaley double precision, skewx double precision, skewy double precision)
  returns raster
immutable
strict
parallel safe
language sql
as $$
SELECT public.ST_setgeoreference($1, array_to_string(ARRAY[$4, $7, $6, $5, $2, $3], ' '))
$$;

comment on function st_setgeoreference(raster, double precision, double precision, double precision, double precision,
                                       double precision, double precision)
is 'args: rast, upperleftx, upperlefty, scalex, scaley, skewx, skewy - Set Georeference 6 georeference parameters in a single call. Numbers should be separated by white space. Accepts inputs in GDAL or ESRI format. Default is GDAL.';

alter function st_setgeoreference(raster, double precision, double precision, double precision, double precision, double precision, double precision)
  owner to postgres;

