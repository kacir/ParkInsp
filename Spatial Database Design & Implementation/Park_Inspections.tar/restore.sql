--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.structures DROP CONSTRAINT structures_parknum_fkey;
ALTER TABLE ONLY public.projectboundary DROP CONSTRAINT projectboundary_parknum_fkey;
ALTER TABLE ONLY public.inspectionnotes DROP CONSTRAINT inspectionnotes_parknum_fkey;
ALTER TABLE ONLY public.structures DROP CONSTRAINT structures_pkey;
ALTER TABLE ONLY public.projectboundary DROP CONSTRAINT projectboundary_pkey;
ALTER TABLE ONLY public.parkfootprints DROP CONSTRAINT parkfootprints_pkey;
ALTER TABLE ONLY public.inspectionnotes DROP CONSTRAINT inspectionnotes_pkey;
ALTER TABLE public.structures ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.projectboundary ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.inspectionnotes ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE public.structures_id_seq;
DROP TABLE public.structures;
DROP SEQUENCE public.projectboundary_id_seq;
DROP TABLE public.projectboundary;
DROP TABLE public.parkfootprints;
DROP SEQUENCE public.inspectionnotes_id_seq;
DROP TABLE public.inspectionnotes;
DROP EXTENSION postgis;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


--
-- Name: postgis; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS postgis WITH SCHEMA public;


--
-- Name: EXTENSION postgis; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION postgis IS 'PostGIS geometry, geography, and raster spatial types and functions';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: inspectionnotes; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE inspectionnotes (
    inspector character varying(50) NOT NULL,
    inspdate date,
    notetype character varying(50) NOT NULL,
    conversion character varying(2),
    note1 character varying(254) NOT NULL,
    geom geometry(Point,4326),
    public_acc character varying(2),
    note2 character varying(254),
    id integer NOT NULL,
    datacorr character varying(2),
    maint character varying(2),
    parknum character varying(50) NOT NULL
);


ALTER TABLE public.inspectionnotes OWNER TO postgres;

--
-- Name: inspectionnotes_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE inspectionnotes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.inspectionnotes_id_seq OWNER TO postgres;

--
-- Name: inspectionnotes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE inspectionnotes_id_seq OWNED BY inspectionnotes.id;


--
-- Name: parkfootprints; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE parkfootprints (
    parknum character varying(50) NOT NULL,
    currname character varying(254) NOT NULL,
    googlelink character varying(254) NOT NULL,
    pastname character varying(254),
    geom geometry(MultiPolygon,4326) NOT NULL
);


ALTER TABLE public.parkfootprints OWNER TO postgres;

--
-- Name: projectboundary; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE projectboundary (
    type character varying(50),
    geom geometry(MultiPolygon,4326) NOT NULL,
    id integer NOT NULL,
    parknum character varying(50)
);


ALTER TABLE public.projectboundary OWNER TO postgres;

--
-- Name: projectboundary_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE projectboundary_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.projectboundary_id_seq OWNER TO postgres;

--
-- Name: projectboundary_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE projectboundary_id_seq OWNED BY projectboundary.id;


--
-- Name: structures; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE structures (
    type character varying(50) NOT NULL,
    label character varying(50),
    geom geometry(MultiPolygon,4326) NOT NULL,
    id integer NOT NULL,
    parknum character varying(50)
);


ALTER TABLE public.structures OWNER TO postgres;

--
-- Name: structures_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE structures_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.structures_id_seq OWNER TO postgres;

--
-- Name: structures_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE structures_id_seq OWNED BY structures.id;


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY inspectionnotes ALTER COLUMN id SET DEFAULT nextval('inspectionnotes_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY projectboundary ALTER COLUMN id SET DEFAULT nextval('projectboundary_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY structures ALTER COLUMN id SET DEFAULT nextval('structures_id_seq'::regclass);


--
-- Data for Name: inspectionnotes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY inspectionnotes (inspector, inspdate, notetype, conversion, note1, geom, public_acc, note2, id, datacorr, maint, parknum) FROM stdin;
\.
COPY inspectionnotes (inspector, inspdate, notetype, conversion, note1, geom, public_acc, note2, id, datacorr, maint, parknum) FROM '$$PATH$$/3208.dat';

--
-- Name: inspectionnotes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('inspectionnotes_id_seq', 1, true);


--
-- Data for Name: parkfootprints; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY parkfootprints (parknum, currname, googlelink, pastname, geom) FROM stdin;
\.
COPY parkfootprints (parknum, currname, googlelink, pastname, geom) FROM '$$PATH$$/3204.dat';

--
-- Data for Name: projectboundary; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY projectboundary (type, geom, id, parknum) FROM stdin;
\.
COPY projectboundary (type, geom, id, parknum) FROM '$$PATH$$/3210.dat';

--
-- Name: projectboundary_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('projectboundary_id_seq', 1, false);


--
-- Data for Name: spatial_ref_sys; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY spatial_ref_sys  FROM stdin;
\.
COPY spatial_ref_sys  FROM '$$PATH$$/3075.dat';

--
-- Data for Name: structures; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY structures (type, label, geom, id, parknum) FROM stdin;
\.
COPY structures (type, label, geom, id, parknum) FROM '$$PATH$$/3206.dat';

--
-- Name: structures_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('structures_id_seq', 1, false);


--
-- Name: inspectionnotes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY inspectionnotes
    ADD CONSTRAINT inspectionnotes_pkey PRIMARY KEY (id, parknum);


--
-- Name: parkfootprints_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY parkfootprints
    ADD CONSTRAINT parkfootprints_pkey PRIMARY KEY (parknum);


--
-- Name: projectboundary_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY projectboundary
    ADD CONSTRAINT projectboundary_pkey PRIMARY KEY (id);


--
-- Name: structures_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY structures
    ADD CONSTRAINT structures_pkey PRIMARY KEY (id);


--
-- Name: inspectionnotes_parknum_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY inspectionnotes
    ADD CONSTRAINT inspectionnotes_parknum_fkey FOREIGN KEY (parknum) REFERENCES parkfootprints(parknum);


--
-- Name: projectboundary_parknum_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY projectboundary
    ADD CONSTRAINT projectboundary_parknum_fkey FOREIGN KEY (parknum) REFERENCES parkfootprints(parknum);


--
-- Name: structures_parknum_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY structures
    ADD CONSTRAINT structures_parknum_fkey FOREIGN KEY (parknum) REFERENCES parkfootprints(parknum);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

